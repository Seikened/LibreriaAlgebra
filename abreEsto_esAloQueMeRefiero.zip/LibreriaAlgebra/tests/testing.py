import ..src.algebraIA.mi_modulo as al

al.matriz()